<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<!-- Direct Test: __FILE__ = " . __FILE__ . " -->\n";
echo "Direct output test in Vik folder is working!";
?>
