# TWP
1. Always Pull/sync changes before edit.
2. Save and commit after edit.
3. Thats all, notice that when two people commit and synch changes at same time, it will open a error log.
4. It will auto merge the different changes, u need to pull or sync changes then.